# Flowers Gift HTML & CSS 💐

Welcome! to my repository that hosts a flowers gift created in HTML & CSS so feel free to gift you special someone on various occasions 
and you can also customize it for you needs.

Including
- Valentines 💓
- Birthdays 🎂
- Girlfriends Day 👩 etc.

## Table of Contents
- [Technologies]
- [Installation]
- [Inspiration]


## Technologies

This project utilizes the following programming languages and technologies:
- HTML
- CSS
- JavaScript

## Installation

To run this project locally, follow these steps:

1. Clone this repository to your local computer:

NB: No additional file or installations are required .


## Inspiration

The creation of this project drew inspiration from this project

https://github.com/FIQTOR/flowers-for-someone

so feel free to support its too.

THANK YOU 
